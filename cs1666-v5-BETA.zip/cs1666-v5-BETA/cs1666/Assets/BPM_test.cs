using UnityEngine;
using System.Collections;
//Sound library import
using SoundTouch;

//Set types used in SoundTouch library
using TSampleType = System.Single;
using TLongSampleType = System.Double;

public class BPM_test : MonoBehaviour {
	
	//Soundbox STUFF
	GameObject protag;

	//Score of player = number of platforms they jumped on
	int player_Score = 0;
	
	//Keeps track of platforms the player has already jumped to so we don't increment his score more than needed
	ArrayList previous_platforms = new ArrayList();
	
	//Decompressed Audio data
	float[] samples;
	float[] new_samples;
	
	public bool timeToEnd = false;
	
	const int BUFFSIZE = 2205;
	
	//Analyze 60 second intervals
	const int TIMEFRAME = 120;
	
	//commonly 44100 Hz or 22050
	const int SAMPLE_RATE = 44100;
	
	//Bounds for songs with HIGH intensity
	const int H_THETA_BOUND = 30;
	const float H_CLAMP_LOW_BOUND = -0.1f;
	const float H_CLAMP_HIGH_BOUND = 0.1f;
	
	//Bounds for songs with LOW intensity score
	const int L_THETA_BOUND = 80;
	const float L_CLAMP_LOW_BOUND = 0.75f;
	const float L_CLAMP_HIGH_BOUND = 1f;
	
	//For bpm analysis
	int starting_position = 0;
	int counter = 0;
	
	//Score of song's intensity
	float intensity_Score = 0;
	
	//Reference to platform generation script
	PlatformGenerator my_script;
	
	//Method to change what platform this script generates based on BPM value
	public string platform_string;
	
	//bpm value
	float bpmValue = 0.0f;
	
	int time_at_bpm = 0;
	
	int time_of_platform_change = 0;
	
	//Arraylist of bpm values
	ArrayList bpm_values = new ArrayList();
	
	//Used to index thru bpm values every ten seconds
	int index_in_list = 0;
	
	//Music currently playing
	AudioSource music_source;
	
	float timeAtDisplay = 0f;
	
	void Start()
	{
		//camera = GameObject.Find("Sphere");
		protag = GameObject.Find ("protagonist");
		
		my_script = GetComponent<PlatformGenerator>();
		
		//Add audio component to protagonist object and set music_source equal to it
		music_source = protag.AddComponent<AudioSource>();
		
		
		//Load in Audio file into audio clip of audio component
		//Songs - (Concerto De Aranjuez Adagio) (Mr. Scary)
		music_source.clip = Resources.Load("Audio/Concerto De Aranjuez Adagio") as AudioClip;
		
		//Array to store sample data from Audio clip component
		samples = new float[protag.audio.clip.samples * protag.audio.clip.channels];
			
		//Get audio data from Unity
		protag.audio.clip.GetData(samples, 0);	
		
		Debug.Log ("Number of samples = " + protag.audio.clip.samples);
		Debug.Log("Audio clip length (sec) = " + protag.audio.clip.length);
		
		//Get bpm values at 10 second intervals
		while (starting_position < protag.audio.clip.samples)
		{
			getBPM();
			
			bpm_values.Add(bpmValue);
		}
		
		//Begin playing song
		protag.audio.Play();
		
		//Get starting time
		time_at_bpm = Mathf.RoundToInt(protag.audio.time);
		
		Debug.Log(bpm_values.Count);
		
		//Pick starting platform
		int pick = Random.Range(1,5);
		switch(pick)
		{
			case 1:
				platform_string = "Turntable Platform";
				break;
			case 2:
				platform_string = "Piano Key Platform";
				break;
			case 3:
				platform_string = "Basic Platform";
				break;
			case 4:
				platform_string = "Basic Platform 2";
				break;
		}
		
		//Get intensity score
		for (int x = 0; x < bpm_values.Count; x++)
		{
			intensity_Score += (float) bpm_values[x];
		}
		
		intensity_Score /= bpm_values.Count;
		
		//Start out generation variables at low values and slowly build up as song continues to play
		if (intensity_Score < 100.0f)
		{
			my_script.coneTheta = 65;
			my_script.lowerSoftClamp = 0.4f; 
			my_script.upperSoftClamp = 0.75f;
		}
		else
		{
			my_script.coneTheta = 30;
			my_script.lowerSoftClamp = -0.1f; 
			my_script.upperSoftClamp = 0.1f;
		}
		
	}
	
	
	void getBPM()
	{
		//Make object of type BpmDetect
		var test = BpmDetect<TSampleType, TLongSampleType>.NewInstance(2, SAMPLE_RATE);
		
		//Make buffer to send the object music sample data
		var sampleBuffer = new TSampleType[BUFFSIZE];
		/*
		//Add 10 second's worth of samples 120 times to get bpm for that second
		for (int j = 0; j < (120/TIMEFRAME); j++)
		{
			counter = starting_position;
			
			//Add 44100 (2205*20) samples to bpm object = 1 sec worth of music
			//it needs around 6 min worth of samples to calculate bpm
			for (int y = 0; y < ((SAMPLE_RATE/BUFFSIZE)*TIMEFRAME); y++)
			{
				for (int x = 0; x < BUFFSIZE; x++)
				{
					sampleBuffer[x] = samples[x+counter];
				}
				counter += BUFFSIZE;
			
				//Have to divide number of samples when using this function because it compresses data into 1 channel
				test.InputSamples(sampleBuffer, BUFFSIZE/2);
			}
		}
		
		//Move starting position forward by one second
		starting_position += (SAMPLE_RATE*TIMEFRAME);
		*/
		
		//Add all samples of song to sound analyzer
		while (counter < protag.audio.clip.samples)
		{
			for (int x = 0; x < BUFFSIZE; x++)
			{
				sampleBuffer[x] = samples[x+counter];
			}
			counter += BUFFSIZE;
		
			//Have to divide number of samples when using this function because it compresses data into 1 channel
			test.InputSamples(sampleBuffer, BUFFSIZE/2);
		}
		
		starting_position = counter;
		
		bpmValue = test.GetBpm();
		
		//Debug.Log ("BPM = " + bpmValue);
		
		
	}
	
	//GUI function displays bpm values
	void OnGUI()
	{
		//GUI.color = Color.green;
		//GUI.backgroundColor = Color.green;
		
		//GUI.Box(new Rect(100, Screen.height - 50, 50, 50), ("" + bpm_values[index_in_list]));
		if (index_in_list >= 0)
		{
			/*
			GUILayout.Label("BPM = " + bpm_values[index_in_list]);
			GUILayout.Label("Saturation Rate = " + my_script.saturationLimit);
			GUILayout.Label("Cone theta = " + my_script.coneTheta);
			GUILayout.Label ("Lower Clamp = " + my_script.lowerClamp);
			GUILayout.Label ("Upper Clamp = " + my_script.upperClamp);
			*/
			
			GUILayout.Label("Intensity score = " + intensity_Score);
			GUILayout.Label("Player Score = " + player_Score);
			//GUI.color = Color.green;
			//GUI.backgroundColor = Color.green;
		
			//GUI.Box(new Rect(100, Screen.height - 50, 50, 50), ("" + bpm_values[index_in_list]));
			//Debug.Log ("BPM = " + bpm_values[index_in_list]);
			
			/*
			Debug.Log("BPM = " + bpm_values[index_in_list]);
			Debug.Log("Saturation Rate = " + my_script.saturationLimit);
			Debug.Log("Cone theta = " + my_script.coneTheta);
			Debug.Log("Lower Clamp = " + my_script.lowerClamp);
			Debug.Log("Upper Clamp = " + my_script.upperClamp);
			*/
		}
		
		if (timeToEnd == true)
		{
			GUI.color = Color.green;
			GUI.backgroundColor = Color.grey;
		
			GUI.Box(new Rect(Screen.width/4, Screen.height/4, Screen.width/2, Screen.height/2), ("A Sandbox of Sound \n\n\n\n Your Score: " + player_Score + "\n\n Thanks For Playing!"));	
			
			if (timeAtDisplay == 0f)
			{
				//Wait 5 seconds then close
				timeAtDisplay = Time.time;
			}
		}
	}
	
	//Checks collisions and keeps score for player
	void OnControllerColliderHit(ControllerColliderHit hit)
	{
		Collider body = hit.collider;
        if (body == null)
            return;
		
		if (body.enabled)
		{
			//Debug.Log("Collision!");
			
			int id = body.GetInstanceID();
			//Increase player score if they hit a new platform
			if (previous_platforms.Contains(id)== false)
			{
				player_Score += 1;
				previous_platforms.Add(id);
				previous_platforms.Sort();
			}
		}
		
		
	}
	
	// Update is called once per frame
	void Update () 
	{	
		int curr_time = Mathf.RoundToInt(protag.audio.time);
		
		//Display score when game is over and exit program
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			//Go display score
			timeToEnd = true;
			//audio.Stop();
			//Debug.Log (timeToEnd);
		}
		
		float t = Time.time;
		
		//Wait 5 seconds then close program
		if (timeToEnd && t > (timeAtDisplay + 8f))
		{
			Application.Quit();

		}
		
		
		//Display new bpm value every TIMEFRAME seconds
		if ( (curr_time >= (time_at_bpm + TIMEFRAME)) && protag.audio.isPlaying == true)
		{
			Debug.Log (curr_time);
			Debug.Log (time_at_bpm);
			
			time_at_bpm = Mathf.RoundToInt(protag.audio.time);
			
			if (index_in_list < bpm_values.Count - 1)
			{
				index_in_list++;
			}
			
			//If BPM has changed we randomly pick a new platform to start generating
			/*	
			if (index_in_list > 0 && bpm_values[index_in_list-1]  != bpm_values[index_in_list])
			{
				//float ratio = (float) bpm_values[index_in_list]/ (float) bpm_values[index_in_list-1];
				//Random.seed = Mathf.RoundToInt(ratio*10); 
				
				int pick = Random.Range(1,5);
			
				switch(pick)
				{
					case 1:
						platform_string = "Turntable Platform";
						//my_script.saturationLimit = 10;
						break;
					case 2:
						platform_string = "Piano Key Platform";
						//my_script.saturationLimit = 3;
						break;
					case 3:
						platform_string = "Basic Platform";
						//my_script.saturationLimit = 30;
						break;
					case 4:
						platform_string = "Falling Platform";
						break;
				}
				
				//Debug.Log ("Pick = " + pick);
				Debug.Log ("Platform type =" + platform_string);
				
				
			}
			*/
		}
		
		//Every 3 seconds change platform
		if ( (curr_time >= (time_of_platform_change + 10)) && protag.audio.isPlaying == true)
		{
			//Inclusive min and exclusive max
			int pick = Random.Range(1,5);
			
			//High chance of getting falling platforms with high intensity song
			if (intensity_Score >= 100f)
			{
				pick = Random.Range(1,9);
				
				if (pick % 2 == 0)
				{
					platform_string = "Falling Platform";
				}
				else
				{
					switch(pick)
					{
						case 1:
							platform_string = "Turntable Platform";
							break;
						case 3:
							platform_string = "Piano Key Platform";
							break;
						case 5:
							platform_string = "Basic Platform";
							break;
						case 7:
							platform_string = "Basic Platform 2";
							break;
					}	
					
				}
			}
			else
			{
				switch(pick)
				{
					case 1:
						platform_string = "Turntable Platform";
						break;
					case 2:
						platform_string = "Piano Key Platform";
						break;
					case 3:
						platform_string = "Basic Platform";
						break;
					case 4:
						platform_string = "Basic Platform 2";
						break;
				}
			}
			//Debug.Log ("Pick = " + pick);
			Debug.Log ("Platform type =" + platform_string);
			
			time_of_platform_change = Mathf.RoundToInt(protag.audio.time);
			
			//If song has low intensity
			if ( intensity_Score < 100f)
			{
				if (my_script.coneTheta <= L_THETA_BOUND)
				{
					my_script.coneTheta += 1;
				}
				if (my_script.lowerSoftClamp <= L_CLAMP_LOW_BOUND)
				{
					my_script.lowerSoftClamp += 0.01f; 
				}
				if (my_script.upperSoftClamp <= L_CLAMP_HIGH_BOUND)
				{
					my_script.upperSoftClamp += 0.01f;
				}
			}
			else
			{
				if (my_script.coneTheta <= H_THETA_BOUND)
				{
					my_script.coneTheta += 1;
				}
				if (my_script.lowerSoftClamp <= H_CLAMP_LOW_BOUND)
				{
					my_script.lowerSoftClamp += 0.01f; 
				}
				if (my_script.upperSoftClamp <= H_CLAMP_HIGH_BOUND)
				{
					my_script.upperSoftClamp += 0.01f;
				}	
			}
		}
		
	}
}

/************SHIT THAT DONT WORK***********************/

/*
		
		new_samples = new float[ball.audio.clip.samples * ball.audio.clip.channels];
		
		left_channel = new float[ball.audio.clip.samples];
		right_channel = new float[ball.audio.clip.samples];
		
		Debug.Log ("Getting samples");
		Debug.Log (ball.audio.clip.samples); //9 million samples for this song
		Debug.Log (ball.audio.clip.channels); //2 channels - stereo
		
		
		
		Debug.Log("Done getting samples");
		
		int conversionFactor = 32767;
		int left_index = 0;
		int right_index = 0;
		
		int position_in_song = 0;
		int history_offset = 0;
		
		double instant_energy = 0.0;
		double local_ave_energy = 0.0;
		float numBeats = 0.0f;
		double variance = 0;
		double c_constant = 0;
		
		//Instatiate bpm detector object
		//my_detector = new BPMDetect.BPMDetection();
		
		//Convert samples from Unity range of (-1.0f, 1.0f) to (-32767.0f, 32767.0f)
		for (int x = 0; x < (ball.audio.clip.samples * 2); x++)
		{
			new_samples[x] = samples[x] * conversionFactor;
			
			//Separate sample data into different channels
			if (x % 2 == 0)
			{
				left_channel[left_index] = new_samples[x];	
				left_index++;
			}
			else
			{
				right_channel[right_index] = new_samples[x];
				right_index++;
			}
			
			
			//Add samples to the detector
			//my_detector.AddSample(new_samples[x]);
			
			
			//test conversion SLOWS down way too much
			//Debug.Log (new_samples[x]);
		}
		
		double[] energy_history = new double[43];
		
		//Compute energy history for first second of song
		for (int j = 0; j < 43; j++)
		{
			//Get instant energy at current position
			for (int x = position_in_song; x < (position_in_song + 1024); x++)
			{
				instant_energy += ((left_channel[x]*left_channel[x]) + (right_channel[x]*right_channel[x]));		
			}
			
			position_in_song += 1024;
			
			energy_history[j] = instant_energy;
			
			instant_energy = 0;
			
		}
		
		while ((position_in_song + 1024) < (44032*60))
		{
			//Get instant energy at current position
			for (int x = position_in_song; x < (position_in_song + 1024); x++)
			{
				instant_energy += ((left_channel[x]*left_channel[x]) + (right_channel[x]*right_channel[x]));	
				
			}
			
			/*
			//Calculate local average energy
			for (int x = history_offset; x < (history_offset + 44032); x++)
			{
				local_ave_energy += ((left_channel[x]*left_channel[x]) + (right_channel[x]*right_channel[x]));
			}
			
			local_ave_energy *= (1024.0f/44100.0f);
			
			
			for (int x = 0; x < 43; x++)
			{
				local_ave_energy += (energy_history[x]*energy_history[x]);	
			}
			
			local_ave_energy /= 43.0;
			
			//calculate variance
			for (int x = 0; x < 43; x++)
			{
				variance += ((energy_history[x] - local_ave_energy) * (energy_history[x] - local_ave_energy));	
			}
			
			variance /= 43.0;
			
			c_constant = (-0.0025714 * variance) + 1.5142857;
			
			//Shift values down
			for (int x = 0; x < 42; x++)
			{
				energy_history[x+1] = energy_history[x];	
			}
			energy_history[0] = instant_energy;
			
			if (instant_energy > (local_ave_energy * c_constant))
			{
				numBeats++;
			}
			
			position_in_song += 1024;
			
			/*
			history_offset += 1024;
			
			//If we go out of bounds reduce history offset
			if ((history_offset + 44032) > (ball.audio.clip.samples / 2))
			{
				history_offset -= 1024;	
			}
			
			
			//reset energy values
			instant_energy = 0.0;
			local_ave_energy = 0.0;
			
		}
		
		int length = Mathf.FloorToInt(ball.audio.clip.length);
		
		Debug.Log (numBeats);
		Debug.Log ("Length: " + length);
		//43 checks a second 
		//this operation gives average beats per second
		numBeats /= (43 * 59);
		
		//Average beats per minute
		numBeats *= 60;
		
		Debug.Log(new_samples[43002]);
		Debug.Log (new_samples[43003]);
		
		//double my_bpm = my_detector.getParameter(BPMDetect.BPMDetection.BPMParam.BPMFOUNDBPM);
		
		Debug.Log ("BPM = " + numBeats);
		*/
